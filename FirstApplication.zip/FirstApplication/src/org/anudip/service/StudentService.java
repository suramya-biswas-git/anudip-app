package org.anudip.service;

import org.anudip.bean.Student;

public class StudentService {
	
	public static String calculateGrade(Student student) {
		double studentMarks=student.getStudentMarks();
		String studentGrade="";
		if(studentMarks>=90)
			studentGrade="E";
		else if(studentMarks>=75)
			studentGrade="G";
		else if(studentMarks>=60)
			studentGrade="P";
		else
			studentGrade="F";
		
		return studentGrade;
	}
}
