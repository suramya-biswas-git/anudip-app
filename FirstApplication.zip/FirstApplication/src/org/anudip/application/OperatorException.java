package org.anudip.application;

public class OperatorException extends RuntimeException {

}
