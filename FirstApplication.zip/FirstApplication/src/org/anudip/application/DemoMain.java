package org.anudip.application;

import org.anudip.bean.Demo;

public class DemoMain {

	public static void main(String[] args) {
		
		
		
		int x=20;
		double y=27.56;
		Demo d3=new Demo(x,y);
		
	}

}
