package org.anudip.string;

import java.util.Scanner;

public class SubStringApp {
	public static String cutString(String str, int n, int m) {
		n--;
		m=n+m;
		String sub=str.substring(n,m);
		return sub;
	}

	public static void main(String[] args) {
		// declare Scanner object
		Scanner sc = new Scanner(System.in);
		// ask to enter a string & accept
		System.out.println("Enter the String: ");
		String str=sc.nextLine();
		// ask to enter the start position & number of chars to display 
		System.out.println("Enter the start position: ");
		int n=Integer.parseInt(sc.nextLine());
		System.out.println("Enter the number of chars to display: ");
		int m=Integer.parseInt(sc.nextLine());
		// invoke method to cut the string
		String sub=cutString(str,n,m);
		// display output
		System.out.println(sub);
	}

}
