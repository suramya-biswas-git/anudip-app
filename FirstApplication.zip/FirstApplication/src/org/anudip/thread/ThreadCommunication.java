package org.anudip.thread;

public class ThreadCommunication {

	public static void main(String[] args) {
		Thread1 t1=new Thread1();
		t1.start();

	}

}
