package org.anudip.inheritance;

public class InheritMain2 {

	public static void main(String[] args) {
    Child2 ch=new Child2();
     ch.show();
	}

}
