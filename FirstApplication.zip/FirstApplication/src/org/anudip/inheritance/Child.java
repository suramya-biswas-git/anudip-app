package org.anudip.inheritance;

class Child extends Parent{
	private double j;
	public Child() {
		j=3.75;
		System.out.println("Child constructor");
	}
	public void display() {
		System.out.println("The value of j:"+j);
	}

}
