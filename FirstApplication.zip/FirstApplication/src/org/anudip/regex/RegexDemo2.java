package org.anudip.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo2 {

	public static void main(String[] args) {
		Pattern p1 = Pattern.compile("[abc]s");
		String s1="as";
		String s2="bs";
		String s3="xs";
		Matcher m1=p1.matcher(s1);
		//System.out.println(m1.matches());
		
		Matcher m2=p1.matcher(s2);
		//System.out.println(m2.matches());
		
		Matcher m3=p1.matcher(s3);
		//System.out.println(m3.matches());
		Pattern p2 = Pattern.compile("[^xyz]s");
		m1=p2.matcher(s1);
		System.out.println(m1.matches());
		
		 m2=p2.matcher(s2);
		System.out.println(m2.matches());
		
		m3=p2.matcher(s3);
		System.out.println(m3.matches());
		

	}

}
