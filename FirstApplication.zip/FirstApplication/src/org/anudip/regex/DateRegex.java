package org.anudip.regex;

public class DateRegex {

	public static void main(String[] args) {
		String strPattern = "^\\d{2}-\\d{2}-\\d{4}$";
		
	}

}
