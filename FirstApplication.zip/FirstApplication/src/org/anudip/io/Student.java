package org.anudip.io;

public class Student {
	private Integer rollNumber;
	private String studentName;
	private Double HalfYearly;
	private Double Annual;
	private String grade;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(Integer rollNumber, String studentName, Double halfYearly, Double annual, String grade) {
		super();
		this.rollNumber = rollNumber;
		this.studentName = studentName;
		HalfYearly = halfYearly;
		Annual = annual;
		this.grade = grade;
	}
	public Student(Integer rollNumber, String studentName, Double halfYearly) {
		super();
		this.rollNumber = rollNumber;
		this.studentName = studentName;
		HalfYearly = halfYearly;
	}
	public Integer getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(Integer rollNumber) {
		this.rollNumber = rollNumber;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public Double getHalfYearly() {
		return HalfYearly;
	}
	public void setHalfYearly(Double halfYearly) {
		HalfYearly = halfYearly;
	}
	public Double getAnnual() {
		return Annual;
	}
	public void setAnnual(Double annual) {
		Annual = annual;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	@Override
	public String toString() {
		return "Student [rollNumber=" + rollNumber + ", studentName=" + studentName + ", HalfYearly=" + HalfYearly
				+ ", Annual=" + Annual + ", grade=" + grade + "]";
	}
	

}
