package org.anudip.io;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class FileIn2 {

	public static void main(String[] args)throws IOException {
					FileInputStream fileIn=new FileInputStream("d:/tulip.txt");
					BufferedInputStream bufferedIn=new BufferedInputStream(fileIn);
				while(true) {
					int x=bufferedIn.read();
					if(x==-1) // -1 means End of file
					  break;
				    char ch=(char)x;
				    System.out.print(ch);
				}
			   fileIn.close();
			   bufferedIn.close();

	}
}