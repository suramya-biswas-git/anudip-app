package org.anudip.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileIn3 {

	public static void main(String[] args)throws IOException {
		        Student []arr=new Student[4];
				FileReader fileReader=new FileReader("d:/StudentResult.txt");
				
				BufferedReader bufferedReader=new BufferedReader(fileReader);
				int i=0;
				while(true) {
					String str=bufferedReader.readLine();
					
					if(str==null)
						break;
					String []brr=str.split("-");
					int id=Integer.parseInt(brr[0]);
					double hf=Double.parseDouble(brr[2]);
					Student student=new Student(id, brr[1], hf);
					arr[i]=student;
					i++;
				}
			   fileReader.close();
			   bufferedReader.close();
			   for(Student std:arr)
				   System.out.println(std);

	}
}