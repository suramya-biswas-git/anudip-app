package org.anudip.array;

import java.util.Arrays;

public class ArrayDemo2 {

	public static void main(String[] args) {
		int []arr= {60,23,57,89,25,54,11,92,73,49};
		int size=arr.length;
		System.out.println("The size of array="+arr.length);
		System.out.println("Display:");
			
		for (int x:arr) {
			System.out.println(x);
		}
			int [] brr=Arrays.copyOf(arr,size);
		
		
		Arrays.sort(brr); // sorting an array
		System.out.println("Display after sort in ascending order:");
		
		for(int x:brr) {
			System.out.println(x);
		}
		
		System.out.println("Display after sort in descending order:");
		for(int i=arr.length-1;i>=0;i--) {
			System.out.println(arr[i]);
		}
	
	}
}
