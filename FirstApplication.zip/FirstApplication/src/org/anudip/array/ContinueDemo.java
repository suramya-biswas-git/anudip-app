package org.anudip.array;

import java.util.Scanner;

public class ContinueDemo {

	public static void main(String[] args) {
		 Scanner scanner=new Scanner(System.in);
		int counter=0;
		while(counter<5) {
			System.out.println("Enter an even number:");
			int p=scanner.nextInt();
			if(p%2!=0)
				continue;
			
				int q=p/2;
				System.out.println("The half of "+p+"="+q);
				counter++;
		}
		scanner.close();

	}

}
