package org.anudip.array;

public class LoopDemo1 {

	public static void main(String[] args) {
		int counter=10;
		while(counter<5) {
			System.out.println("hello");
			counter++;
		}// end looping statement
      System.out.println("outside the loop");
	}

}
