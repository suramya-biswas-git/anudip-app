package org.anudip.array;

public class LoopDemo2 {

	public static void main(String[] args) {
		int counter=10;
		 do {
			System.out.println("hello");
			counter++;
		}while(counter<5);// end looping statement
      System.out.println("outside the loop");
	}

}
