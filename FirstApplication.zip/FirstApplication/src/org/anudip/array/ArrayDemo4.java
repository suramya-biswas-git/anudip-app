package org.anudip.array;

import java.util.Arrays;
//import java.util.Arrays;
import java.util.Scanner;

public class ArrayDemo4 {

	public static void main(String[] args) {
		int []arr= {60,80,20,100,70,10,40,90,50,30};
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a number to find whether it is present in array :");
		int n=scanner.nextInt();
		Arrays.sort(arr);
		int result=Arrays.binarySearch(arr,n);
		if(result>=0)
		   System.out.println("Value present in array");
		else
			System.out.println("Value not present in array");
		
	}
}
