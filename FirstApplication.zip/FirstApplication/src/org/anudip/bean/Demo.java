package org.anudip.bean;

public class Demo {
	private int i;
	private double j;
	public Demo() {
		i=1;
		j=1.0;
		System.out.println("Non arg constructor");
	}
	public Demo (int p,double q) {
		this();
		i=p;
		j=q;
		System.out.println("Para constructor");
	}
	public Demo (Demo d) {
		this.i=d.i;
		this.j=d.j;
		System.out.println("Copy constructor");
	}
	
	public void display() {
		System.out.println("The value of i:"+i);
		System.out.println("The value of j:"+j);
	}
}
