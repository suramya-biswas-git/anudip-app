package org.anudip.lambda;

import java.util.Scanner;

public class AdditionMain {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		AdditionFace af=(x,y)->{
			return x+y;
		};
		System.out.println("Enter 1st operand:");
		int i=Integer.parseInt(scanner.nextLine());
		System.out.println("Enter 2nd operand:");
		int j=Integer.parseInt(scanner.nextLine());
		int r=af.add(i, j);
		System.out.println("The result:"+r);
	}

}
