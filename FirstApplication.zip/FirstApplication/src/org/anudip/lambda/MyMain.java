package org.anudip.lambda;

public class MyMain {

	public static void main(String[] args) {
	  D dd=new DImpl();
	  dd.disp();
	  dd.show();
	 // dd.putdata();
	  

	}

}
