package org.anudip.lambda;

public class DImpl implements D{
	@Override
	public void show() {
		System.out.println("Hello World");
	}
	@Override
	public void disp() {
		System.out.println("Hi World");
	}
	public void putdata() {
		System.out.println("Hello hi");
	}
}
