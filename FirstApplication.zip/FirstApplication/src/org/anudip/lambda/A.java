package org.anudip.lambda;

public class A {
	int i;
	public void show() {
		System.out.println("hello");
	}
	public void putdata() {
		System.out.println("bye ");
	}

}
