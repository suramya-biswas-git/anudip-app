package org.anudip.lambda;

@FunctionalInterface
public interface AdditionFace {
	int add(int x, int y);
	

}
