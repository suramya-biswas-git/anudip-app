package org.anudip.interfaceApp;

public interface DemoFace {
	 void show();
	 void display();
	 int p=10;

}
