package org.anudip.interfaceApp;

public class Child extends Parent {
	@Override
	public void show() {
		System.out.println("bye");

	}

	@Override
	public void display() {
		System.out.println("Ta ta bye ");
	}

}
