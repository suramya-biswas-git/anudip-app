package org.anudip.interfaceApp;

public class MyDemoFaceImpl implements MyDemoFace {

	@Override
	public void show() {
		System.out.println("hi people how is today?");
	}
	public void dispMessage() {
		System.out.println("good day people");
	}
}
