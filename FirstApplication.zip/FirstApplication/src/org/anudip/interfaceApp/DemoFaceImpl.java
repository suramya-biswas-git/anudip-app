package org.anudip.interfaceApp;

public class DemoFaceImpl implements DemoFace {

	@Override
	public void show() {
		System.out.println("Hello everybody");
			}

	@Override
	public void display() {
		System.out.println("Hi everybody");

	}
	
	
	public void putdata() {
		System.out.println("Hello Hi");
	}
	

}
