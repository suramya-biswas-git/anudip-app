package abc;

public class StudentResult {
	String rollNumber;

	String studentName;

	Double halfYearlyTotal;

	Double annualTotal;

	String grade;

	public StudentResult() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public Double getHalfYearlyTotal() {
		return halfYearlyTotal;
	}

	public void setHalfYearlyTotal(Double halfYearlyTotal) {
		this.halfYearlyTotal = halfYearlyTotal;
	}

	public Double getAnnualTotal() {
		return annualTotal;
	}

	public void setAnnualTotal(Double annualTotal) {
		this.annualTotal = annualTotal;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	@Override
	public String toString() {
		return  rollNumber + "-"+ studentName + "-"+ halfYearlyTotal + "-" + annualTotal + "-" + grade;
	}
	
	
}
