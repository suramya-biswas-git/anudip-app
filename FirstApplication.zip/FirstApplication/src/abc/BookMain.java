package abc;

import java.util.Comparator;
import java.util.List;

public class BookMain {

	public static void main(String[] args) {
		 List<Book> books = Library.getAllBooks();
		  books.sort(Comparator.comparing(Book::getBookNumber));
		  books.forEach(bk->System.out.println(bk));
		  System.out.println("==================");
		  books.sort(Comparator.comparing(Book::getBookTitle));
		  books.forEach(bk->System.out.println(bk));
		  System.out.println("==================");
		  books.sort(Comparator.comparing(Book::getAuthor));
		  books.forEach(bk->System.out.println(bk));
	}

}
