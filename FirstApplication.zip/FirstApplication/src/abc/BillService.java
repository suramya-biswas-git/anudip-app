package abc;

public class BillService {
	//calculate each purchased item price
	public String itemPurchasedPayable(Item item) {
		Double amount = item.getRate()*item.getQtyOrdered();
		return String.valueOf(amount);
	}
	
//	calculates sales tax payable 
	 public String saleTaxCalculation(double total){ 
		 double saleTax = total *(12.5/100);
		 return String.valueOf(saleTax);
	 }
	 
//	  10% discount calculation
	 public String discountCalculation(double total) {
		 return String.valueOf((total > 5000) ? total * 0.1 :0.0);
	 }

}
