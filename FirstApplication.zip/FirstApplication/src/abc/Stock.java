package abc;

import java.util.LinkedHashMap;
import java.util.Map;

public class Stock {
	 private static Map<String,Item> itemMap = new LinkedHashMap<>();
//	 put at least 6 items with name and price
	 static {
		 itemMap.put("RICE",new Item("RICE", 67.50));
		 itemMap.put("WHEAT",new Item("WHEAT",55.00));
		 itemMap.put("SUGAR",new Item("SUGAR",45.00 ));
		 itemMap.put("COFFEE",new Item("COFFEE",150.00));
		 itemMap.put("TEA",new Item("TEA",125.50));
		 itemMap.put("TOOTHPASTE",new Item("TOOTHPASTE",75.00));
		 itemMap.put("DAL",new Item("DAL",85.00));	 
	 }
     
//	 return those items map
	 public static Map<String,Item> getAllItems(){
		 return itemMap;
	 }
	 
//	return specific item object 
	 public static Item getItem(String itemName) {
		 itemName = itemName.toUpperCase();
		 return itemMap.get(itemName);
	 }


}
