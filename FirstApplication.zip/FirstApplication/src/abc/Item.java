package abc;

import java.text.DecimalFormat;

public class Item {
	DecimalFormat df = new DecimalFormat("0.00");
	private String itemName;
	private Double rate;
	private Double qtyOrdered;
	private Double amountPayable;
	public Item() {
		// default constructor
		super();
	}
	public Item(String itemName, Double rate) {
		// parameterized constructor
		super();
		this.itemName = itemName;
		this.rate = rate;
	}
	public Item(String itemName, Double rate, Double qtyOrdered) {
		// parameterized constructor
		super();
		this.itemName = itemName;
		this.rate = rate;
		this.qtyOrdered = qtyOrdered;
	}
	// using getter and setter method to set value into 
//	   this class member variable and return this value
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Double getRate() {
		return rate;
	}
	public void setRate(Double rate) {
		this.rate = rate;
	}
	public Double getQtyOrdered() {
		return qtyOrdered;
	}
	public void setQtyOrdered(Double qtyOrdered) {
		this.qtyOrdered = qtyOrdered;
	}
	public Double getAmountPayable() {
		return amountPayable;
	}
	public void setAmountPayable(Double amountPayable) {
		this.amountPayable = amountPayable;
	}
	
//	using toString method to print something by using this format
	@Override  
	public String toString() {
		String str = String.format("%-20s %-20s %-20s %-20s",itemName,df.format(rate),df.format(qtyOrdered),df.format( amountPayable));
		return str;
	}

}
