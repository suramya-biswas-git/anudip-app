package abc;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class ResultMain {
	 /*private static StudentResult[] allStudents=null;
	 private static void convertToList() throws Exception{
		 FileReader fileReader=new FileReader("d:/StudentResult.txt");
			
			BufferedReader bufferedReader=new BufferedReader(fileReader);
			
			int i=0;
			while(true) {
				
				String str=bufferedReader.readLine();
				// EOF bufferedReader will return null value
				if(str==null)
					break;
			 String[] arr=str.split("-");
			 StudentResult studentResult=new StudentResult();
			 studentResult.setRollNumber(arr[0]);
			 studentResult.setStudentName(arr[1]);
			 studentResult.setHalfYearlyTotal(Double.parseDouble(arr[2]));
			 allStudents[i]=studentResult;
			}	 
			 
			 fileReader.close();
				
			}
		 
	 }

	public static void main(String[] args) throws Exception{
		// your code 
		
		FileWriter fileWriter=new FileWriter("d:/StudentResult.txt");
		// BufferedWriter will write inside the file which fileWriter is pointing to i.e Lotus.txt
		BufferedWriter bufferedWriter=new BufferedWriter(fileWriter);
		//accept data from user
		for(StudentResult studentResult: allStudents) {
		String str=studentResult.toString();
		// BufferedWriter transfer to content to the File
		bufferedWriter.write(str);
		bufferedWriter.flush();
		bufferedWriter.newLine();
		}
		bufferedWriter.close();
		fileWriter.close();
		scanner.close();
		System.out.println("File written");

	}*/

}
