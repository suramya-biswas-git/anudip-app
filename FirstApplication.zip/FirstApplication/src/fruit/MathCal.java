package fruit;

import java.util.Scanner;

public class MathCal {

	public static void main(String[] args) {
		 Scanner scanner=new Scanner(System.in);
		 System.out.println("Enter 1st operand:");
		 int operand1=Integer.parseInt(scanner.nextLine());
		 System.out.println("Enter 2nd operand:");
		 int operand2=Integer.parseInt(scanner.nextLine());
		 System.out.println("Enter Math operator:");
		 String operator=scanner.nextLine();
		 
		 int result=0;
		 switch(operator) {
		  
		 case "+" : result=operand1+operand2;break;
		 case "-" : result=operand1-operand2;break;
		 case "*" : result=operand1*operand2;break;
		 case "/" : result=operand1/operand2;break;
		 case "%" : result=operand1%operand2;break;
		 default : System.out.println("Wrong Math operator");
		  }
		
		 System.out.println("The result:"+result);
   }
}
