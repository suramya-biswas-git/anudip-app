package fruit;
import flower.*; // import statement imports classes of a foreign package in current application

public class FruitView {

	public static void main(String[] args) {
      Rose.show();	 	

	}

}
