package fruit;

public class DataTypeDemo {

	public static void main(String[] args) {
		double d=5.00;
		float p=5.00f;
		float k=(float)d; //explicit type casting ---> demotional--> from higher range to lower range  
		double q=p; //implicit type casting ---> promotional--> from lower range to higher range
		int x=77526;
		long t=x;
		short r=(short)x;
		System.out.println("The value of x:"+x);
		System.out.println("The value of t:"+t);
		System.out.println("The value of r:"+r);
		int n=45000;
	short z=(short)n;
	System.out.println("The value of z:"+z);
	 char h='d';
	 System.out.println("The value of h:"+h);
	 int rr=(int)h;
	 System.out.println("The value of rr:"+rr);
	 byte bb=(byte)h;
	 System.out.println("The value of bb:"+bb);
	 boolean bl=true;
	 System.out.println("The value of bl:"+bl);
	 
		
		
		
		
	}

}
