package fruit;

public class Base {
	private int i;
	public Base() {
		i=10;
		System.out.println("Parent constructor");
	}
protected void show() {
		System.out.println("the value of i:"+i);
	}

}
