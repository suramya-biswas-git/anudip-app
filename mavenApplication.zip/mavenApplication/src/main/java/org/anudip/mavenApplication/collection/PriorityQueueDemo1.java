package org.anudip.mavenApplication.collection;

import java.util.PriorityQueue;

public class PriorityQueueDemo1 {

	public static void main(String[] args) {
		PriorityQueue<String> myQueue=new PriorityQueue<String>();
		System.out.println("Original List");
		myQueue.add("Mango");
		myQueue.add("Apple");
		myQueue.add("Guava");
		myQueue.add("Pineapple");
		myQueue.add("Lichi");
		myQueue.add("Plum");
		myQueue.forEach(str->System.out.println(str));
		System.out.println("Peeking:");
		System.out.println(myQueue.peek());
		System.out.println("After peeking the queue is:");
		myQueue.forEach(str->System.out.println(str));
	}
}
