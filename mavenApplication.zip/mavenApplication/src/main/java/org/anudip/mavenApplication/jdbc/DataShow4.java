package org.anudip.mavenApplication.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DataShow4 {

 public static void main(String[] args)throws Exception {
	 Class.forName("oracle.jdbc.driver.OracleDriver"); 
	 Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","scott","tiger");
	 String sqlStatement="Select studentid,firstname,lastname,to_char(dateofbirth,'DD-MM-YYYY'),gender,email,phone from student";
	 Statement statement=connection.createStatement();
	 ResultSet resultSet=statement.executeQuery(sqlStatement);
	   while(resultSet.next()) {
		   String id=resultSet.getString(1);
		   String fname=resultSet.getString(2);
		   String lname=resultSet.getString(3);
		   String dob=resultSet.getString(4);
		   String gender=resultSet.getString(5);
		   String email=resultSet.getString(6);
		   String phone=resultSet.getString(7);
		    System.out.println(id+"-"+fname+"-"+lname+"-"+dob+"-"+gender+"-"+email+"-"+phone);
		 } 
	   connection.close();
	}
}
