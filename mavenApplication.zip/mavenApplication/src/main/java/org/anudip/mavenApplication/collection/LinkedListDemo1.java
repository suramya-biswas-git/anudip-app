package org.anudip.mavenApplication.collection;

import java.util.LinkedList;
import java.util.Collections;
import java.util.ListIterator;

public class LinkedListDemo1 {

	public static void main(String[] args) {
		LinkedList<String> myList=new LinkedList<String>();
		myList.add("Rose");
		myList.add("Lotus");
		myList.add("Lily");
		myList.add("Rose");
		myList.add("Marigold");
		myList.add("Jasmine");
		myList.add("Cosmos");
		myList.add("Jasmine");
		myList.add("Delhia");
		myList.add("Zenia");
		myList.add("Tulip");
		myList.addLast("Lavender");
		myList.addFirst("Sunflower");	
	
		System.out.println("Display in the order of entry with forEach loop:-");
		for(String str:myList) {
			System.out.println(str);
		}
		ListIterator<String> iterator=myList.listIterator();
		System.out.println("Display in the order of entry from 1st to last with ListIterator :-");
		
		while(iterator.hasNext()) {
			String stg=iterator.next();
			System.out.println(stg);
		}
		System.out.println("Display in the order of entry from last to 1st with ListIterator :-");
		while(iterator.hasPrevious()) {
			String stg=iterator.previous();
			System.out.println(stg);
		}
		
		System.out.println("Display in the order of entry with Lambda Expression:-");
		myList.forEach(str->System.out.println(str));
		
		/*System.out.println("Display in ascending order:-");
		Collections.sort(myList);
		myList.forEach(str->System.out.println(str));
		
		System.out.println("Display in descending order:-");
		Collections.reverse(myList);
		myList.forEach(str->System.out.println(str));*/
	}
}
