package org.anudip.mavenApplication.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseHandler2 {
	private static DatabaseHandler2 dbHandler=new DatabaseHandler2();
	
	private DatabaseHandler2() {
		
	}
	public static DatabaseHandler2 getDatabaseHandler() {
		return dbHandler;
	}
	
	
	public Connection getConnection() throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver"); 
		Connection connection=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/c5904","root","root");
		 return connection;
	}

}
