package org.anudip.mavenApplication.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
public class DataInsert3 {
 public static void main(String[] args)throws Exception {
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter Student Id:");
	String id=scanner.nextLine();
	System.out.println("Enter First Name:");
	String fname=scanner.nextLine();
	System.out.println("Enter Last Name:");
	String lname=scanner.nextLine();
	System.out.println("Enter Date of birth (dd-mm-yyyy):");
	String dob=scanner.nextLine();
	System.out.println("Enter Gender:");
	String gender=scanner.nextLine();
	System.out.println("Enter Email:");
	String email=scanner.nextLine();
	System.out.println("Enter Phone Number:");
	String phone=scanner.nextLine();
	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","scott","tiger");
	String sqlStatement="insert into student values (?,?,?,to_date(?,'DD-MM-YYYY'),?,?,?)";
	PreparedStatement statement=connection.prepareStatement(sqlStatement);
	statement.setString(1,id);
	statement.setString(2,fname);
	statement.setString(3,lname);
	statement.setString(4,dob);
	statement.setString(5,gender);
	statement.setString(6,email);
	statement.setString(7,phone);
	statement.executeUpdate();
	System.out.println("New Record inserted");
	connection.close();
  }
}
