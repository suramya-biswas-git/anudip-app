package org.anudip.mavenApplication.generic;

public class Demo {
	int p;
	double q;
	public Demo(int p, double q) {
		super();
		this.p = p;
		this.q = q;
	}
	@Override
	public String toString() {
		return "Demo [p=" + p + ", q=" + q + "]";
	}
	

}
