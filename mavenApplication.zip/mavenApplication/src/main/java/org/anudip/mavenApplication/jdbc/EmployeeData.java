package org.anudip.mavenApplication.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class EmployeeData {
	private static Scanner scanner=new Scanner(System.in);
	 public static void insert() throws Exception{
		 System.out.println("Enter Employee Id:");
			int id=Integer.parseInt(scanner.nextLine());
			System.out.println("Enter Employee Name:");
			String name=scanner.nextLine();
			System.out.println("Enter Basic");
			double basic=Double.parseDouble(scanner.nextLine());
			DatabaseHandler dbHandler=DatabaseHandler.getDatabaseHandler();
			Connection connection=dbHandler.getConnection();
			String sqlStatement="insert into empmast (employee_id,employee_name,basic) values (?,?,?)";
			PreparedStatement statement=connection.prepareStatement(sqlStatement);
			    statement.setInt(1,id);
			    statement.setString(2,name);
			    statement.setDouble(3,basic);
			    statement.executeUpdate();
			    System.out.println("New Employee inserted");
			     connection.close();
		 
	 }
	 public static void update() throws Exception{
		 // ask to enter emp id for net calculation
		System.out.println("Enter employee Id whose net to calculate:");
		int id=Integer.parseInt(scanner.nextLine());
		DatabaseHandler dbHandler=DatabaseHandler.getDatabaseHandler();
		 Connection connection=dbHandler.getConnection();
		 // find that employee from database
	    String sqlStatement="Select * from empmast where employee_id=?";
	    PreparedStatement statement=connection.prepareStatement(sqlStatement);
	    statement.setInt(1,id);
	     ResultSet resultSet=statement.executeQuery();
	     resultSet.next();
	     int empId=resultSet.getInt(1);
	     String empName=resultSet.getString(2);
	     double empBasic=resultSet.getDouble(3);
	     Employee emp=new Employee(empId, empName, empBasic);
	     // display employee details upto basic
	     System.out.println(emp);
	     // calculate net & assigned to the net attribute of the employee
	     emp=EmployeeService.netCalculation(emp);
	     // display employee details with net
	     System.out.println(emp);
	     // update in database
	     String sqlStatement2="update empmast set net=? where employee_id=?";
		  PreparedStatement statement2=connection.prepareStatement(sqlStatement2);
		  statement2.setDouble(1,emp.getNet());
		  statement2.setInt(2,emp.getEmployeeId());
		  statement2.executeUpdate();
		  System.out.println("Net Calculated & Updated");
		  connection.close();
	     }
	
	public static void main(String[] args) throws Exception {
		while(true) {
			System.out.println("1.Employee Addition");
			System.out.println("2.Employee Updation");
			System.out.println("3.Exit");
			System.out.println("Choice(1-3):");
			String choice=scanner.nextLine();
			switch (choice) {
			case "1" : insert();break;
			case "2" : update();break;
			case "3" :System.exit(0);
			}// end of switch
		}// end of loop
	}

}
