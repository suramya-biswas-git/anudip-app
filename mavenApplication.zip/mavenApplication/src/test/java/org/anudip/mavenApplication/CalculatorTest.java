package org.anudip.mavenApplication;


import static org.junit.jupiter.api.Assertions.*;

import org.anudip.mavenApplication.app.Calculator;
import org.anudip.mavenApplication.app.OperatorException;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTest {
	private static Calculator cal;
	private int p;
	private String s1;
	
	@BeforeAll
	public static void beforeAll() {
		cal=new Calculator();
		System.out.println("Before all is called");
	}
	
	@BeforeEach
	public void beforeEach() {
		p=30;
		s1="30";
		System.out.println("Before each is called");
	}
	
	@Test
	void testAddition() {
		int q=20;
		int expected=50;
		int actual=cal.addition(p,q);
		assertEquals(expected,actual);
		
	}

	@Test
	void testMultiply() {
		int q=2;
		String r="?";
		assertThrows(OperatorException.class, ()->cal.multiply(p,q,r));
		}

	@Test
	void testDivision1() {
		String s2="5";
		int expected=6;
		int actual=cal.division(s1,s2);
		assertEquals(expected,actual);
	}
	@Test
	void testDivision2() {
		String s2="0";
		assertThrows(ArithmeticException.class, ()->cal.division(s1,s2));
	}
	@Test
	void testDivision3() {
		String s2="a";
		assertThrows(NumberFormatException.class, ()->cal.division(s1,s2));
	}
	@AfterAll
	public static void afterAll() {
		cal=null;
		System.out.println("After all is called");
	}
	@AfterEach
	public void afterEach() {
		System.out.println("After each is called");
	}

}
